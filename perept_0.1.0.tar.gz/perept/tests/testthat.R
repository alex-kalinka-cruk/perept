library(testthat)
library(perept)

test_check("perept")
